'use strict';
/**
 * Phase 6 — Observation Repository Hardening Tests
 *
 * Covers:
 *   1. saveObservationSubmission() input guards
 *   2. Transaction atomicity (failed record insert rolls back the header row)
 *   3. Round-trip retrieval via getObservationAssessment()
 *   4. Grade R ('0') survives storage/retrieval without falsy-drop
 *   5. Record ordering (id ASC)
 *
 * Run individually:   node tests/phase-6-observation-repository.test.js
 * Run via npm:        npm test
 */

// ── Shared real-migrations test DB helper (see docs/TSE_SCHOOL_CALENDAR_TEST_GAP.md) ──
const { createTestDb } = require('./helpers/createTestDb');

let _db = null;

// ── Helpers ───────────────────────────────────────────────────────────────────
let passed = 0;
let failed = 0;

function assert(condition, label) {
  if (condition) {
    console.log(`  ✅ ${label}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${label}`);
    failed++;
  }
}

function assertEq(a, b, label) {
  const ok = JSON.stringify(a) === JSON.stringify(b);
  if (ok) {
    console.log(`  ✅ ${label}`);
    passed++;
  } else {
    console.error(`  ❌ FAIL: ${label}`);
    console.error(`     expected: ${JSON.stringify(b)}`);
    console.error(`     got:      ${JSON.stringify(a)}`);
    failed++;
  }
}

function assertThrows(fn, expectedMsg, label) {
  try {
    fn();
    console.error(`  ❌ FAIL: ${label} — expected throw, got no error`);
    failed++;
  } catch (err) {
    if (expectedMsg && !err.message.includes(expectedMsg)) {
      console.error(`  ❌ FAIL: ${label}`);
      console.error(`     expected message to include: "${expectedMsg}"`);
      console.error(`     got: "${err.message}"`);
      failed++;
    } else {
      console.log(`  ✅ ${label}`);
      passed++;
    }
  }
}

// ── Test runner ───────────────────────────────────────────────────────────────
async function run() {
  const testDb = createTestDb(__filename);
  _db = testDb.db;

  const { saveObservationSubmission, getObservationAssessment } =
    require('../services/observationRepository');

  const PHONE = 'obs_test_hash_001';
  _db.prepare(`INSERT OR IGNORE INTO teachers (phone_hash) VALUES (?)`).run(PHONE);

  // ═══════════════════════════════════════════════════════════════════════════
  // SECTION 1: saveObservationSubmission() input guards
  // ═══════════════════════════════════════════════════════════════════════════

  console.log('\n── Section 1: saveObservationSubmission() input guards ─────────────');

  console.log('\nTest P6-01: null phoneHash → throws with clear message');
  assertThrows(
    () => saveObservationSubmission(null, { grade: '0' }, [
      { learnerName: 'Thabo', domain: 'Counting', developmentalStatus: 'Developing' },
    ]),
    'phoneHash must not be null or empty',
    'null phoneHash throws'
  );

  console.log('\nTest P6-02: empty string phoneHash → throws');
  assertThrows(
    () => saveObservationSubmission('', { grade: '0' }, [
      { learnerName: 'Thabo', domain: 'Counting', developmentalStatus: 'Developing' },
    ]),
    'phoneHash must not be null or empty',
    'empty string phoneHash throws'
  );

  console.log('\nTest P6-03: null records → throws');
  assertThrows(
    () => saveObservationSubmission(PHONE, { grade: '0' }, null),
    'records must be a non-empty array',
    'null records throws'
  );

  console.log('\nTest P6-04: empty records array → throws');
  assertThrows(
    () => saveObservationSubmission(PHONE, { grade: '0' }, []),
    'records must be a non-empty array',
    'empty records array throws'
  );

  console.log('\nTest P6-05: non-array records (object) → throws');
  assertThrows(
    () => saveObservationSubmission(PHONE, { grade: '0' }, { not: 'an array' }),
    'records must be a non-empty array',
    'non-array records throws'
  );

  // ═══════════════════════════════════════════════════════════════════════════
  // SECTION 2: Round-trip retrieval, including Grade R ('0') safety
  // ═══════════════════════════════════════════════════════════════════════════

  console.log('\n── Section 2: Round-trip retrieval ──────────────────────────────────');

  console.log('\nTest P6-06: full submission round-trips with correct shape');
  const header = { grade: '0', subject: 'Numeracy', assessment: 'Term 2 Observation' };
  const records = [
    { learnerName: 'Thabo', domain: 'Counting', developmentalStatus: 'Developing', notes: 'Counts to 10 confidently.' },
    { learnerName: 'Lindiwe', domain: 'Counting', developmentalStatus: 'Achieved', notes: null },
  ];
  const { assessmentId, recordCount } = saveObservationSubmission(PHONE, header, records);
  assertEq(recordCount, 2, 'recordCount reflects number of records saved');
  assert(typeof assessmentId === 'number', 'assessmentId is a number');

  const result = getObservationAssessment(assessmentId);
  assertEq(result.phoneHash, PHONE, 'phoneHash matches on retrieval');
  assertEq(result.grade, '0', "Grade R ('0') survives round-trip, not dropped/nulled by falsy checks");
  assertEq(result.subject, 'Numeracy', 'subject matches on retrieval');
  assertEq(result.assessmentName, 'Term 2 Observation', 'assessmentName matches on retrieval');
  assertEq(result.records.length, 2, 'both records retrieved');
  assertEq({
    learnerName: result.records[0].learnerName,
    domain: result.records[0].domain,
    developmentalStatus: result.records[0].developmentalStatus,
    notes: result.records[0].notes,
    resolved: result.records[0].resolved,
  }, {
    learnerName: 'Thabo',
    domain: 'Counting',
    developmentalStatus: 'Developing',
    notes: 'Counts to 10 confidently.',
    resolved: false,
  }, 'first record matches exactly (unresolved by default)');
  assertEq({
    learnerName: result.records[1].learnerName,
    domain: result.records[1].domain,
    developmentalStatus: result.records[1].developmentalStatus,
    notes: result.records[1].notes,
    resolved: result.records[1].resolved,
  }, {
    learnerName: 'Lindiwe',
    domain: 'Counting',
    developmentalStatus: 'Achieved',
    notes: null,
    resolved: false,
  }, 'second record matches exactly, null notes preserved, unresolved by default');

  console.log('\nTest P6-07: missing/undefined header fields stored as null, not dropped');
  const { assessmentId: minimalId } = saveObservationSubmission(PHONE, {}, [
    { learnerName: 'Sipho', domain: 'Fine Motor', developmentalStatus: 'Emerging', notes: null },
  ]);
  const minimalResult = getObservationAssessment(minimalId);
  assert(minimalResult.grade === null, 'grade is null when not provided');
  assert(minimalResult.subject === null, 'subject is null when not provided');
  assert(minimalResult.assessmentName === null, 'assessmentName is null when not provided');

  console.log('\nTest P6-08: getObservationAssessment returns null for non-existent id');
  const missing = getObservationAssessment(999999);
  assert(missing === null, 'non-existent assessment id returns null');

  console.log('\nTest P6-09: record ordering is deterministic (id ASC)');
  const { assessmentId: orderId } = saveObservationSubmission(PHONE, { grade: '2' }, [
    { learnerName: 'A', domain: 'X', developmentalStatus: 'Achieved', notes: null },
    { learnerName: 'B', domain: 'X', developmentalStatus: 'Achieved', notes: null },
    { learnerName: 'C', domain: 'X', developmentalStatus: 'Achieved', notes: null },
  ]);
  const orderResult = getObservationAssessment(orderId);
  assertEq(
    orderResult.records.map(r => r.learnerName),
    ['A', 'B', 'C'],
    'records retrieved in insertion (id ASC) order'
  );

  // ═══════════════════════════════════════════════════════════════════════════
  // SECTION 3: Transaction atomicity
  // ═══════════════════════════════════════════════════════════════════════════

  console.log('\n── Section 3: Transaction atomicity ─────────────────────────────────');

  console.log('\nTest P6-10: failed record insert rolls back the assessment header row');
  const ROLLBACK_PHONE = 'obs_rollback_hash';
  _db.prepare(`INSERT OR IGNORE INTO teachers (phone_hash) VALUES (?)`).run(ROLLBACK_PHONE);

  // Second record is missing required NOT NULL fields (domain, developmentalStatus),
  // which should fail partway through the loop, after the header row and the
  // first record have already been inserted in-transaction.
  const badRecords = [
    { learnerName: 'Valid Learner', domain: 'Reading', developmentalStatus: 'Achieved', notes: null },
    { learnerName: 'Broken Learner', domain: null, developmentalStatus: null, notes: null },
  ];

  assertThrows(
    () => saveObservationSubmission(ROLLBACK_PHONE, { grade: '1', subject: 'Literacy' }, badRecords),
    null,
    'submission with an invalid record throws'
  );

  const leftoverAssessments = _db
    .prepare('SELECT * FROM observation_assessments WHERE phone_hash = ?')
    .all(ROLLBACK_PHONE);
  const leftoverRecords = _db
    .prepare(`
      SELECT r.* FROM observation_records r
      JOIN observation_assessments a ON a.id = r.assessment_id
      WHERE a.phone_hash = ?
    `)
    .all(ROLLBACK_PHONE);

  assertEq(leftoverAssessments.length, 0, 'assessment header does not survive a failed transaction');
  assertEq(leftoverRecords.length, 0, 'no orphaned records survive a failed transaction');

  console.log('\nTest P6-11: after a rollback, a valid retry succeeds cleanly');
  const retrySave = saveObservationSubmission(ROLLBACK_PHONE, { grade: '1', subject: 'Literacy' }, [
    { learnerName: 'Valid Learner', domain: 'Reading', developmentalStatus: 'Achieved', notes: null },
  ]);
  assert(retrySave.assessmentId > 0, 'retry after rollback returns a valid assessmentId');
  assertEq(retrySave.recordCount, 1, 'retry saves the expected record count');

  // ── Summary ───────────────────────────────────────────────────────────────
  console.log(`\n${'─'.repeat(55)}`);
  console.log(`Phase 6 Results: ${passed} passed, ${failed} failed`);

  testDb.cleanup();

  if (failed > 0) process.exit(1);
}

run().catch(err => {
  console.error('Unexpected test error:', err);
  process.exit(1);
});
